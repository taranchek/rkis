let str = 'avb a1b a2b a3b a4b a5b abb acb';

console.log(str.match(/a\Db/g));