let str = 'aba accca azzza wwwwa';

console.log(str.replace(/a.+?a/g, '!'));