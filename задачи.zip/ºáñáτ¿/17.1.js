let str = 'aeeea aeea aea axa axxa axxxa';

console.log(str.match(/a(e+|x+)a/g));