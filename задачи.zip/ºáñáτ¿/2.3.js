let str = 'aa aba abba abbba abca abea';

console.log(str.match(/ab?a/g));