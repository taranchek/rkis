let str = 'a1a a22a a333a a4444a a55555a aba aca';

console.log(str.match(/a\d+a/g));