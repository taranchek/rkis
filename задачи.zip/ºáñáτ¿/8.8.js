let str = 'aAXa aeffa aGha aza ax23a a3sSa';

console.log(str.match(/a[a-z0-9]+a/g));