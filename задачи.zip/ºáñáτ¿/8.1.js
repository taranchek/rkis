let str = 'aba aea aca aza axa';

console.log(str.match(/a[bex]a/g));