let str = 'aba aea afa aha aga';

console.log(str.match(/a[a-g]a/g));