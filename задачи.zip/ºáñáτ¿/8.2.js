let str = 'a1a a3a a7a a9a aba';

console.log(str.match(/a[3-6]a/g));