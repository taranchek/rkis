let str = 'a.a aba aea';

console.log(str.match(/a\.a/g));