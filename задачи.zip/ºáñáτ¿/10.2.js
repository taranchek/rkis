let str = 'ааа ббб ёёё ззз ййй ААА БББ ЁЁЁ ЗЗЗ ЙЙЙ';

console.log(str.match(/[А-ЯЁа-яё]+/g));