let str = 'ave a#a a2a a$a a4a a5a a-a aca';

console.log(str.replace(/\s/g, '!'));