let str = '^xx axx ^zz bkk';

console.log(str.match(/[^\^][a-z][a-z]/g));