let str = '23 2+3 2++3 2+++3 445 677';

console.log(str.match(/2\+*3/g));