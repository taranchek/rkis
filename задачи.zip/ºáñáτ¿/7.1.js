let str = 'a1a a2a a3a a4a a5a aba aca';

console.log(str.match(/a\da/g));