let str = 'wйw wяw wёw wqw';

console.log(str.match(/w[а-яё]w/g));